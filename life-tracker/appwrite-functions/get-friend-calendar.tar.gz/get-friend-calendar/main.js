// appwrite-functions/get-friend-calendar/main.js
import { Client, Databases, Query } from 'node-appwrite';

export default async ({ req, res, log, error }) => {
    // 1. Identify the caller
    const callerId = req.headers['x-appwrite-user-id'];
    if (!callerId) {
        error('Unauthorized: No user ID found in request headers.');
        return res.json({ error: 'Unauthorized' }, 401);
    }

    // 2. Parse and validate the request body
    let friendUserId;
    try {
        const body = JSON.parse(req.body);
        friendUserId = body.friendUserId;
        if (!friendUserId) {
            throw new Error('friendUserId is required');
        }
    } catch (e) {
        error(`Bad Request: Invalid body - ${e.message}`);
        return res.json({ error: 'Bad Request: friendUserId is required' }, 400);
    }

    // Prevent users from fetching their own data via this endpoint
    if (callerId === friendUserId) {
        error('Bad Request: Cannot request your own calendar via this function.');
        return res.json({ error: 'Bad Request: Invalid target user' }, 400);
    }

    // 3. Initialize the Admin Client with the API key
    const client = new Client()
        .setEndpoint('https://sgp.cloud.appwrite.io/v1')
        .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
        .setKey(process.env.APPWRITE_API_KEY);

    const databases = new Databases(client);
    const DATABASE_ID = 'life_tracker';

    try {
        // 4. SECURITY CHECK: Verify an accepted friendship exists
        const friendships = await databases.listDocuments(
            DATABASE_ID,
            'friendships',
            [
                Query.equal('user_id', callerId),
                Query.equal('friend_id', friendUserId),
                Query.equal('status', 'accepted'),
                Query.limit(1) // We only need to know if at least one exists
            ]
        );

        if (friendships.total === 0) {
            error(`Forbidden: No accepted friendship from ${callerId} to ${friendUserId}.`);
            return res.json({ error: 'Forbidden: You are not friends with this user' }, 403);
        }

        // 5. Fetch and filter the friend's data
        // Fetch tasks that are not private
        const tasks = await databases.listDocuments(DATABASE_ID, 'tasks', [
            Query.equal('user_id', friendUserId),
            Query.equal('deleted', false),
            Query.notEqual('visibility', 'private'), // Core privacy enforcement
            Query.orderAsc('date'),
            Query.limit(1000) // Apply a sensible limit
        ]);

        // Fetch categories that are not private
        const categories = await databases.listDocuments(DATABASE_ID, 'categories', [
            Query.equal('user_id', friendUserId),
            Query.equal('deleted', false),
            Query.notEqual('visibility', 'private'),
            Query.orderAsc('order'),
            Query.limit(100)
        ]);

        log(`Successfully fetched calendar for friend ${friendUserId} for user ${callerId}.`);

        // 6. Return the sanitized data
        return res.json({
            tasks: tasks.documents,
            categories: categories.documents
        });

    } catch (err) {
        error(`Internal Server Error: ${err.message}`);
        // Return a generic error to avoid leaking internal details
        return res.json({ error: 'An internal error occurred' }, 500);
    }
};